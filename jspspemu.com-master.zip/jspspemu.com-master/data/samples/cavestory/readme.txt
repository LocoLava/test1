Cave Story PSP
release candidate 1

Firmware 1.0:
should work with no modification

Firmware 1.5:
needs kxploiting

Custom firmware: (3.XX OE):
should work with no modification
goes in the GAME150 folder

Game saves:
works with saves from the windows version
filename needs to be Profile.dat (case sensitive)
(same for 290.rec)

-Z.
7/8/07



---------------------------------------------------------------------

Known game script bugs:
(mostly due to the widescreen format,
some things become visible that used to be offscreen)

various signs and item descriptions:
- text is misaligned or overflows the textbox

first fight with Balrog:
- part of the sprite remains visible at the top after he escapes

egg corridor:
- flying enemies sometimes appear in the air on-screen
- Igor walking away with Sue: sprite disappears too soon

back in Arthur's house:
- text is cut off ("Scanning for...")

back in Arthur's house after Grasstown:
- text is cut off ("...kidnapped")

labyrinth:
- Monster X appears too late, when its corridor is already onscreen

dark place:
- water level not perfect

the core:
- when Curly walks to the right, she disappears and re-appears

plantation:
- some junk spaces when receiving the new sprinkler

prefab building:
- text is cut off (Booster's note)

after last boss:
- Sue's sprite disappears when running away to the left (balcony)

hell:
- flying butes appear in the air in the first hallway

ending credits:
- one bed sprite sticks out of the map in the nurse mini-scene
- clouds act weird during the cloudy mini-scene

...I should fix these sometime in the future.
